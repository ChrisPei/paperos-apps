#!/bin/sh
set -eu
if [ ! -f "$PAPEROS_DATA_DIR/preserved.txt" ]; then printf keep-me > "$PAPEROS_DATA_DIR/preserved.txt"; fi
printf "1.0.0" > "$PAPEROS_DATA_DIR/ran-version"
